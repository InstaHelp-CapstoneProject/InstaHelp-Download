package com.dicoding.instahelp.API

data class LoginResidentRequest(
    val email: String,       // Email pengguna
    val password: String     // Kata sandi pengguna
)
