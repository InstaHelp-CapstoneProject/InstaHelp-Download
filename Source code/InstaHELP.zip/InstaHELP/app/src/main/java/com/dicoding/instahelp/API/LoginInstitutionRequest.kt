package com.dicoding.instahelp.API

data class LoginInstitutionRequest(
    val email: String,       // Email pengguna
    val password: String     // Kata sandi pengguna
)
