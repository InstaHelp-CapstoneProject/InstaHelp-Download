package com.dicoding.instahelp.API

data class ForgotPasswordRequest(
    val email: String
)
